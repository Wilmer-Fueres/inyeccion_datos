<?php
require_once 'config.php';
session_start();

// Validación de campos (opcional, pero recomendada)
if (empty($_POST['usuario']) || empty($_POST['contraseña'])) {
    $_SESSION['alerta'] = [
        'clase' => 'alert-warning',
        'contenido' => 'Introduzca nombre de usuario y contraseña',
    ];
    header('Location: login.php');
    die();
}

// Establecemos la conexión a la base de datos
$conexión = new mysqli(
    $mysql['host'],
    $mysql['usuario'],
    $mysql['contraseña'],
    $mysql['basededatos']
);

// Manejo de errores de conexión
if ($conexión->connect_error) {
    die("Error de conexión: " . $conexión->connect_error);
}

// Establecemos el juego de caracteres (opcional, pero recomendado)
$conexión->set_charset('utf8');

// Preparamos la consulta
//$consulta = $conexión->query("
   //SELECT *
   //FROM accounts
//WHERE username = '{$usuario}' AND password = '{$contraseña}'
//");
$stmt = $conexión->prepare("
    SELECT *
    FROM accounts
    WHERE username = ? AND password = ?
");

// Vinculamos los parámetros
$stmt->bind_param("ss", $_POST['usuario'], $_POST['contraseña']);

// Ejecutamos la consulta
$stmt->execute();

// Obtenemos los resultados
$resultado = $stmt->get_result();

// Verificamos si se encontró un usuario
if ($resultado->num_rows === 1) {
    $datos = $resultado->fetch_assoc();
    $_SESSION['usuario'] = $datos;
    header('Location: aplicacion.php');
} else {
    $_SESSION['alerta'] = [
        'clase' => 'alert-danger',
        'contenido' => 'Usuario o contraseña incorrecta',
    ];
    header('Location: login.php');
}

// Cerramos la consulta y la conexión
$stmt->close();
$conexión->close();